package com.npst.mobileservice.service;

import org.apache.log4j.Logger;

import com.npst.mobileservice.util.Util;

public class AboutUsInfoService {
	private static final Logger log = Logger.getLogger(AboutUsInfoService.class);
	private static String aboutUs = Util.getProperty("aboutUs");

	public String getAboutUs() {
		log.info("Return about us is " + aboutUs);
		return aboutUs;
	}

}
