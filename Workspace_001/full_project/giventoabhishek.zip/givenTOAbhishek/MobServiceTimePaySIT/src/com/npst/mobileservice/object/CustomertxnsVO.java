package com.npst.mobileservice.object;

import java.io.Serializable;

public class CustomertxnsVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -6259237447992017698L;

	private Integer CustomerTxnsId;

	private Integer regvpaId;

	private String txnNote = "";

	private Integer txnType = 0;

	private String txnId = "";

	private String txncustRef = "";

	private String collectExpiry = "";

	private String customerHistory = "";

	private Integer status = 0;

	private String errorCode = "";

	private String payerVpa = "";

	private String payerName = "";

	private String payerAccNo = "";
	private String payerAccIFSC = "";
	private String payerMobileNo = "";
	private String payerMMID = "";
	private String payerAcType = "";
	private String payeeName = "";
	private String payeeVpa = "";
	private String payeeAccNo = "";
	private String payeeAccIFSC = "";
	private String payeeMobileNo = "";
	private String payeeMMID = "";
	private String payeeAcType = "";
	private String amount = "";
	private String reqDate;
	private String respDate;
	private ComplaintVO complaintVo;
	private String complaintFlag;
	private String payeeType;

	public String getPayeeType() {
		return payeeType;
	}

	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}

	public String getComplaintFlag() {
		return complaintFlag;
	}

	public void setComplaintFlag(String complaintFlag) {
		this.complaintFlag = complaintFlag;
	}

	public ComplaintVO getComplaintVo() {
		return complaintVo;
	}

	public void setComplaintVo(ComplaintVO complaintVo) {
		this.complaintVo = complaintVo;
	}

	/*
	 * public CustomertxnsVO(CustomerTxns customertxn) { super(); CustomerTxnsId =
	 * customertxn.getCustomerTxnsId(); this.regvpaId = customertxn.getRegId();
	 * this.txnNote = customertxn.getTxncustRef(); this.txnType =
	 * customertxn.getTxnType(); this.txnId = customertxn.getTxnId();
	 * this.txncustRef = customertxn.getTxncustRef(); this.collectExpiry =
	 * customertxn.getCollectExpiry(); this.customerHistory =
	 * customertxn.getCustomerHistory(); this.status = customertxn.getStatus();
	 * this.errorCode = customertxn.getErrorCode(); this.payerVpa =
	 * customertxn.getPayerVpa(); this.payerName = customertxn.getPayerName();
	 * this.payerAccNo = customertxn.getPayerAccNo(); this.payerAccIFSC =
	 * customertxn.getPayerAccIFSC(); this.payerMobileNo =
	 * customertxn.getPayerMobileNo(); this.payerMMID = customertxn.getPayerMMID();
	 * this.payerAcType = customertxn.getPayerAcType(); this.payeeName =
	 * customertxn.getPayeeName(); this.payeeVpa = customertxn.getPayeeVpa();
	 * this.payeeAccNo = customertxn.getPayeeAccNo(); this.payeeAccIFSC =
	 * customertxn.getPayeeAccIFSC(); this.payeeMobileNo =
	 * customertxn.getPayeeMobileNo(); this.payeeMMID = customertxn.getPayeeMMID();
	 * this.payeeAcType = customertxn.getPayeeAcType(); this.amount =
	 * customertxn.getAmount(); this.reqDate = customertxn.getReqDate();
	 * this.respDate = customertxn.getRespDate(); }
	 */

	public CustomertxnsVO() {
		// TODO Auto-generated constructor stub
	}

	public String getAmount() {
		return amount;
	}

	public String getCollectExpiry() {
		return collectExpiry;
	}

	public String getCustomerHistory() {
		return customerHistory;
	}

	public Integer getCustomerTxnsId() {
		return CustomerTxnsId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getPayeeAccIFSC() {
		return payeeAccIFSC;
	}

	public String getPayeeAccNo() {
		return payeeAccNo;
	}

	public String getPayeeAcType() {
		return payeeAcType;
	}

	public String getPayeeMMID() {
		return payeeMMID;
	}

	public String getPayeeMobileNo() {
		return payeeMobileNo;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public String getPayeeVpa() {
		return payeeVpa;
	}

	public String getPayerAccIFSC() {
		return payerAccIFSC;
	}

	public String getPayerAccNo() {
		return payerAccNo;
	}

	public String getPayerAcType() {
		return payerAcType;
	}

	public String getPayerMMID() {
		return payerMMID;
	}

	public String getPayerMobileNo() {
		return payerMobileNo;
	}

	public String getPayerName() {
		return payerName;
	}

	public String getPayerVpa() {
		return payerVpa;
	}

	public Integer getRegvpaId() {
		return regvpaId;
	}

	public String getReqDate() {
		return reqDate;
	}

	public String getRespDate() {
		return respDate;
	}

	public Integer getStatus() {
		return status;
	}

	public String getTxncustRef() {
		return txncustRef;
	}

	public String getTxnId() {
		return txnId;
	}

	public String getTxnNote() {
		return txnNote;
	}

	public Integer getTxnType() {
		return txnType;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public void setCollectExpiry(String collectExpiry) {
		this.collectExpiry = collectExpiry;
	}

	public void setCustomerHistory(String customerHistory) {
		this.customerHistory = customerHistory;
	}

	public void setCustomerTxnsId(Integer customerTxnsId) {
		CustomerTxnsId = customerTxnsId;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setPayeeAccIFSC(String payeeAccIFSC) {
		this.payeeAccIFSC = payeeAccIFSC;
	}

	public void setPayeeAccNo(String payeeAccNo) {
		this.payeeAccNo = payeeAccNo;
	}

	public void setPayeeAcType(String payeeAcType) {
		this.payeeAcType = payeeAcType;
	}

	public void setPayeeMMID(String payeeMMID) {
		this.payeeMMID = payeeMMID;
	}

	public void setPayeeMobileNo(String payeeMobileNo) {
		this.payeeMobileNo = payeeMobileNo;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public void setPayeeVpa(String payeeVpa) {
		this.payeeVpa = payeeVpa;
	}

	public void setPayerAccIFSC(String payerAccIFSC) {
		this.payerAccIFSC = payerAccIFSC;
	}

	public void setPayerAccNo(String payerAccNo) {
		this.payerAccNo = payerAccNo;
	}

	public void setPayerAcType(String payerAcType) {
		this.payerAcType = payerAcType;
	}

	public void setPayerMMID(String payerMMID) {
		this.payerMMID = payerMMID;
	}

	public void setPayerMobileNo(String payerMobileNo) {
		this.payerMobileNo = payerMobileNo;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	public void setPayerVpa(String payerVpa) {
		this.payerVpa = payerVpa;
	}

	public void setRegvpaId(Integer regvpaId) {
		this.regvpaId = regvpaId;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public void setRespDate(String respDate) {
		this.respDate = respDate;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public void setTxncustRef(String txncustRef) {
		this.txncustRef = txncustRef;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public void setTxnNote(String txnNote) {
		this.txnNote = txnNote;
	}

	public void setTxnType(Integer txnType) {
		this.txnType = txnType;
	}

}
