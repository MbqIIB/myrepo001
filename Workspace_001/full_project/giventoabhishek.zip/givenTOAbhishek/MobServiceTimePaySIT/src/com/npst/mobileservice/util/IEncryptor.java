package com.npst.mobileservice.util;

public interface IEncryptor {
	String encrypt(final String p0) throws Exception;

	String decrypt(final String p0) throws Exception;
}
