package com.npst.mobileservice.object;

public class ReqRespAuthMandatePayeesdetailsVO {

	private String payeeAddr;
	private String payeeName;
	private String mandateAmount;
	private String mandateRecurrencepattern;
	private Long idpayeescol;
	private Long idReqRespAuthMandate;
	private String txnId;
	private String headMsgId;
	private String payeeHandal;
	private String payeeSeqNum;
	private String payeeType;
	private String payeeCode;
	private String infoIdType;
	private String infoId;
	private String infoIdVerifiedName;
	private String infoIdRatingvaddr;
	private String acAddrType;
	private String acAddrTypeDetail1;
	private String acAddrTypeDetail2;
	private String acAddrTypeDetail3;
	private String deviceMobile;
	private String deviceGeocode;
	private String deviceLocation;
	private String deviceIp;
	private String deviceType;
	private String deviceId;
	private String deviceOs;
	private String deviceApp;
	private String deviceCapability;
	private String deviceTelecom;
	private String amountCrr;
	private String amountVal;
	private String mandateName;
	private String mandateTxnId;
	private String mandateUmn;
	private String mandateTs;
	private String mandateRevokeable;
	private String mandateShareToPayee;
	private String mandateType;
	private String mandateValidityStart;
	private String mandateValidityEnd;
	private String mandateAmountvalue;
	private String mandateAmountrule;
	private String mandateRecurrenceRulevalue;
	private String mandateRecurrenceRuletype;
	
	public Long getIdpayeescol() {
		return idpayeescol;
	}
	public void setIdpayeescol(Long idpayeescol) {
		this.idpayeescol = idpayeescol;
	}
	public Long getIdReqRespAuthMandate() {
		return idReqRespAuthMandate;
	}
	public void setIdReqRespAuthMandate(Long idReqRespAuthMandate) {
		this.idReqRespAuthMandate = idReqRespAuthMandate;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public String getHeadMsgId() {
		return headMsgId;
	}
	public void setHeadMsgId(String headMsgId) {
		this.headMsgId = headMsgId;
	}
	public String getPayeeHandal() {
		return payeeHandal;
	}
	public void setPayeeHandal(String payeeHandal) {
		this.payeeHandal = payeeHandal;
	}
	public String getPayeeSeqNum() {
		return payeeSeqNum;
	}
	public void setPayeeSeqNum(String payeeSeqNum) {
		this.payeeSeqNum = payeeSeqNum;
	}
	public String getPayeeType() {
		return payeeType;
	}
	public void setPayeeType(String payeeType) {
		this.payeeType = payeeType;
	}
	public String getPayeeCode() {
		return payeeCode;
	}
	public void setPayeeCode(String payeeCode) {
		this.payeeCode = payeeCode;
	}
	public String getInfoIdType() {
		return infoIdType;
	}
	public void setInfoIdType(String infoIdType) {
		this.infoIdType = infoIdType;
	}
	public String getInfoId() {
		return infoId;
	}
	public void setInfoId(String infoId) {
		this.infoId = infoId;
	}
	public String getInfoIdVerifiedName() {
		return infoIdVerifiedName;
	}
	public void setInfoIdVerifiedName(String infoIdVerifiedName) {
		this.infoIdVerifiedName = infoIdVerifiedName;
	}
	public String getInfoIdRatingvaddr() {
		return infoIdRatingvaddr;
	}
	public void setInfoIdRatingvaddr(String infoIdRatingvaddr) {
		this.infoIdRatingvaddr = infoIdRatingvaddr;
	}
	public String getAcAddrType() {
		return acAddrType;
	}
	public void setAcAddrType(String acAddrType) {
		this.acAddrType = acAddrType;
	}
	public String getAcAddrTypeDetail1() {
		return acAddrTypeDetail1;
	}
	public void setAcAddrTypeDetail1(String acAddrTypeDetail1) {
		this.acAddrTypeDetail1 = acAddrTypeDetail1;
	}
	public String getAcAddrTypeDetail2() {
		return acAddrTypeDetail2;
	}
	public void setAcAddrTypeDetail2(String acAddrTypeDetail2) {
		this.acAddrTypeDetail2 = acAddrTypeDetail2;
	}
	public String getAcAddrTypeDetail3() {
		return acAddrTypeDetail3;
	}
	public void setAcAddrTypeDetail3(String acAddrTypeDetail3) {
		this.acAddrTypeDetail3 = acAddrTypeDetail3;
	}
	public String getDeviceMobile() {
		return deviceMobile;
	}
	public void setDeviceMobile(String deviceMobile) {
		this.deviceMobile = deviceMobile;
	}
	public String getDeviceGeocode() {
		return deviceGeocode;
	}
	public void setDeviceGeocode(String deviceGeocode) {
		this.deviceGeocode = deviceGeocode;
	}
	public String getDeviceLocation() {
		return deviceLocation;
	}
	public void setDeviceLocation(String deviceLocation) {
		this.deviceLocation = deviceLocation;
	}
	public String getDeviceIp() {
		return deviceIp;
	}
	public void setDeviceIp(String deviceIp) {
		this.deviceIp = deviceIp;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceOs() {
		return deviceOs;
	}
	public void setDeviceOs(String deviceOs) {
		this.deviceOs = deviceOs;
	}
	public String getDeviceApp() {
		return deviceApp;
	}
	public void setDeviceApp(String deviceApp) {
		this.deviceApp = deviceApp;
	}
	public String getDeviceCapability() {
		return deviceCapability;
	}
	public void setDeviceCapability(String deviceCapability) {
		this.deviceCapability = deviceCapability;
	}
	public String getDeviceTelecom() {
		return deviceTelecom;
	}
	public void setDeviceTelecom(String deviceTelecom) {
		this.deviceTelecom = deviceTelecom;
	}
	public String getAmountCrr() {
		return amountCrr;
	}
	public void setAmountCrr(String amountCrr) {
		this.amountCrr = amountCrr;
	}
	public String getAmountVal() {
		return amountVal;
	}
	public void setAmountVal(String amountVal) {
		this.amountVal = amountVal;
	}
	public String getMandateName() {
		return mandateName;
	}
	public void setMandateName(String mandateName) {
		this.mandateName = mandateName;
	}
	public String getMandateTxnId() {
		return mandateTxnId;
	}
	public void setMandateTxnId(String mandateTxnId) {
		this.mandateTxnId = mandateTxnId;
	}
	public String getMandateUmn() {
		return mandateUmn;
	}
	public void setMandateUmn(String mandateUmn) {
		this.mandateUmn = mandateUmn;
	}
	public String getMandateTs() {
		return mandateTs;
	}
	public void setMandateTs(String mandateTs) {
		this.mandateTs = mandateTs;
	}
	public String getMandateRevokeable() {
		return mandateRevokeable;
	}
	public void setMandateRevokeable(String mandateRevokeable) {
		this.mandateRevokeable = mandateRevokeable;
	}
	public String getMandateShareToPayee() {
		return mandateShareToPayee;
	}
	public void setMandateShareToPayee(String mandateShareToPayee) {
		this.mandateShareToPayee = mandateShareToPayee;
	}
	public String getMandateType() {
		return mandateType;
	}
	public void setMandateType(String mandateType) {
		this.mandateType = mandateType;
	}
	public String getMandateValidityStart() {
		return mandateValidityStart;
	}
	public void setMandateValidityStart(String mandateValidityStart) {
		this.mandateValidityStart = mandateValidityStart;
	}
	public String getMandateValidityEnd() {
		return mandateValidityEnd;
	}
	public void setMandateValidityEnd(String mandateValidityEnd) {
		this.mandateValidityEnd = mandateValidityEnd;
	}
	public String getMandateAmountvalue() {
		return mandateAmountvalue;
	}
	public void setMandateAmountvalue(String mandateAmountvalue) {
		this.mandateAmountvalue = mandateAmountvalue;
	}
	public String getMandateAmountrule() {
		return mandateAmountrule;
	}
	public void setMandateAmountrule(String mandateAmountrule) {
		this.mandateAmountrule = mandateAmountrule;
	}
	public String getMandateRecurrenceRulevalue() {
		return mandateRecurrenceRulevalue;
	}
	public void setMandateRecurrenceRulevalue(String mandateRecurrenceRulevalue) {
		this.mandateRecurrenceRulevalue = mandateRecurrenceRulevalue;
	}
	public String getMandateRecurrenceRuletype() {
		return mandateRecurrenceRuletype;
	}
	public void setMandateRecurrenceRuletype(String mandateRecurrenceRuletype) {
		this.mandateRecurrenceRuletype = mandateRecurrenceRuletype;
	}
	public String getMandateAmount() {
		return mandateAmount;
	}
	public void setMandateAmount(String mandateAmount) {
		this.mandateAmount = mandateAmount;
	}
	public String getMandateRecurrencepattern() {
		return mandateRecurrencepattern;
	}
	public void setMandateRecurrencepattern(String mandateRecurrencepattern) {
		this.mandateRecurrencepattern = mandateRecurrencepattern;
	}
	public String getPayeeAddr() {
		return payeeAddr;
	}
	public void setPayeeAddr(String payeeAddr) {
		this.payeeAddr = payeeAddr;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	
}
