package com.npst.mobileservice.object;

import java.util.Date;

import com.npst.upi.hor.Blockedbycustomer;

public class BlockedbycustomerVO implements java.io.Serializable {

	private int idblockedbycustomer;
	private Integer status;
	private Integer regid;
	private String blockedvpa;
	private Date blockeddate;
	private Date expirydate;

	public BlockedbycustomerVO(Blockedbycustomer blockedbycustomer) {
		super();
		this.idblockedbycustomer = blockedbycustomer.getIdblockedbycustomer();
		this.status = blockedbycustomer.getStatus();
		this.regid = blockedbycustomer.getRegid();
		this.blockedvpa = blockedbycustomer.getBlockedvpa();
		this.blockeddate = blockedbycustomer.getBlockeddate();
		this.expirydate = blockedbycustomer.getExpirydate();
	}

	public Date getBlockeddate() {
		return this.blockeddate;
	}

	public String getBlockedvpa() {
		return this.blockedvpa;
	}

	public Date getExpirydate() {
		return this.expirydate;
	}

	public int getIdblockedbycustomer() {
		return this.idblockedbycustomer;
	}

	public Integer getRegid() {
		return this.regid;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setBlockeddate(Date blockeddate) {
		this.blockeddate = blockeddate;
	}

	public void setBlockedvpa(String blockedvpa) {
		this.blockedvpa = blockedvpa;
	}

	public void setExpirydate(Date expirydate) {
		this.expirydate = expirydate;
	}

	public void setIdblockedbycustomer(int idblockedbycustomer) {
		this.idblockedbycustomer = idblockedbycustomer;
	}

	public void setRegid(Integer regid) {
		this.regid = regid;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
