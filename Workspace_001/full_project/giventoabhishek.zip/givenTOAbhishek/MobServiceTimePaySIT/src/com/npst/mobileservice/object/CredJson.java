package com.npst.mobileservice.object;

import java.io.Serializable;

public class CredJson implements Serializable {

	private String cred;
	private String subType;
	private Data data;
	private String type;
	private static final long serialVersionUID = 1L;

	public String getCred() {
		return this.cred;
	}

	public Data getData() {
		return this.data;
	}

	public String getSubType() {
		return this.subType;
	}

	public String getType() {
		return this.type;
	}

	public void setCred(String cred) {
		this.cred = cred;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public void setType(String type) {
		this.type = type;
	}
}
