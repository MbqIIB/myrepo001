package com.npst.upiserver.issuer;

public interface TestIssuer {

}
