package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.npst.upiserver.entity.Transno;

@Repository
public interface TransnoRepository extends CrudRepository<Transno, Long>  {
	/*@Procedure(name = "getTrans")
    String getTransNo(@Param("p_OrgId") int p_OrgId);*/
}
