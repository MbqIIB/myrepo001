package com.npst.upiserver.dto;

public class ValAddrCustomerDto {
	private long regId;
	private Integer status;
	private String name;
	private String accType;
	private String custType;
	private String ifsc;
	private String custCode;

	public ValAddrCustomerDto() {
	}

	public ValAddrCustomerDto(long regId, Integer status, String name, String accType, String custType,String ifsc,String custCode) {
		this.regId = regId;
		this.status = status;
		this.name = name;
		this.accType = accType;
		this.custType = custType;
		this.ifsc=ifsc;
		this.custCode=custCode;
	}

	public long getRegId() {
		return regId;
	}

	public void setRegId(long regId) {
		this.regId = regId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
}
