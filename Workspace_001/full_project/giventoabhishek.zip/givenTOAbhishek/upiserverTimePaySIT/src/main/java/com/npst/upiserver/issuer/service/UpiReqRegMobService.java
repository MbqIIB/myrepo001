package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqRegMob;

public interface UpiReqRegMobService {
	void issuerProcess(ReqRegMob reqRegMob);
}
