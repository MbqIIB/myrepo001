package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.ReqRespMandatesPayeesEntity;

public interface ReqRespMandatesPayeesRepo extends JpaRepository<ReqRespMandatesPayeesEntity, Long> {


}
