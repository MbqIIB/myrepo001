package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.ListPspEntity;

public interface ListPspRepo extends JpaRepository<ListPspEntity, Long> {

}
