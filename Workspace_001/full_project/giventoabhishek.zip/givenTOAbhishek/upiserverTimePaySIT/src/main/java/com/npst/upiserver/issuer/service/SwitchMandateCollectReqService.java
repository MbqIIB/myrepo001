package com.npst.upiserver.issuer.service;

import com.npst.upiserver.dto.ReqResp;

public interface SwitchMandateCollectReqService {

	void sendToNpci(ReqResp reqJson);

}
