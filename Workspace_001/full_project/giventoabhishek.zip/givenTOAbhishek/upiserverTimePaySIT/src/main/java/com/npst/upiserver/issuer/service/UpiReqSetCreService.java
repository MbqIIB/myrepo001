package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqSetCre;

public interface UpiReqSetCreService {
	void issuerProcess(ReqSetCre reqSetCre);
}
