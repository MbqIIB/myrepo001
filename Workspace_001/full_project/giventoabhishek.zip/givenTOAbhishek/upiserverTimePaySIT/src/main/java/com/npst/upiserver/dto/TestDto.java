package com.npst.upiserver.dto;

public class TestDto {

}
