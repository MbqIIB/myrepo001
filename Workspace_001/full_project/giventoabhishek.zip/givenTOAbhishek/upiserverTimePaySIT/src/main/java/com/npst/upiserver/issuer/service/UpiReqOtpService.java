package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqOtp;

public interface UpiReqOtpService {
	void issuerProcess(ReqOtp reqOtp);
}
