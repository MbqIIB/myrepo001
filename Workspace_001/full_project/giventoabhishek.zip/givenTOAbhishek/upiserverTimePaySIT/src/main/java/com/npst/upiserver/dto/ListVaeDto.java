package com.npst.upiserver.dto;

public class ListVaeDto {
	private String addr;
	private String keyValue;
	private String keyCode;
	private String keyKi;
	private String keyType;
	
	
	public ListVaeDto(String keyValue, String keyCode, String keyKi, String keyType) {
		super();
		this.keyValue = keyValue;
		this.keyCode = keyCode;
		this.keyKi = keyKi;
		this.keyType = keyType;
	}
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getKeyValue() {
		return keyValue;
	}
	public void setKeyValue(String keyValue) {
		this.keyValue = keyValue;
	}
	public String getKeyCode() {
		return keyCode;
	}
	public void setKeyCode(String keyCode) {
		this.keyCode = keyCode;
	}
	public String getKeyKi() {
		return keyKi;
	}
	public void setKeyKi(String keyKi) {
		this.keyKi = keyKi;
	}
	public String getKeyType() {
		return keyType;
	}
	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}
	
	
	
}
