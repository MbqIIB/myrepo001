package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqHbt;

public interface UpiReqHbtService {
	void issuerProcess(ReqHbt reqHbt);
}
