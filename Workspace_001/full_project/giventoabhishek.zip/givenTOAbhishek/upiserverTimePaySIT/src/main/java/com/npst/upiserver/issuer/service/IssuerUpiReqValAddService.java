package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqValAdd;

public interface IssuerUpiReqValAddService {
	void issuerProcess(final ReqValAdd reqValAdd);
}
