package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.npst.upiserver.entity.FirInfo;

@Repository
public interface FirInfoRepository extends JpaRepository<FirInfo, Long> {

}
