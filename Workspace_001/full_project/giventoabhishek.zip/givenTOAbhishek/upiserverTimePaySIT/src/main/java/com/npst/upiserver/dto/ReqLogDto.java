package com.npst.upiserver.dto;

import java.io.Serializable;
import java.util.Date;

public class ReqLogDto implements Serializable {
	
	private Integer				requestLogId;
	
	private String				txnId;
	
	private String				requestType;
	
	private String				messageId;
	
	private String				parentMessageId;
	
	private String				xmlMessage;
	
	private String				xmlType;
	
	private Date				createdate;
	
	private static final long	serialVersionUID	= -2807470719766743219L;
	
	public Date getCreatedate() {
		return createdate;
	}
	
	public String getMessageId() {
		return messageId;
	}
	
	public String getParentMessageId() {
		return parentMessageId;
	}
	
	public Integer getRequestLogId() {
		return requestLogId;
	}
	
	public String getRequestType() {
		return requestType;
	}
	
	public String getTxnId() {
		return txnId;
	}
	
	public String getXmlMessage() {
		return xmlMessage;
	}
	
	public String getXmlType() {
		return xmlType;
	}
	
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
	public void setParentMessageId(String parentMessageId) {
		this.parentMessageId = parentMessageId;
	}
	
	public void setRequestLogId(Integer requestLogId) {
		this.requestLogId = requestLogId;
	}
	
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	public void setXmlMessage(String xmlMessage) {
		this.xmlMessage = xmlMessage;
	}
	
	public void setXmlType(String xmlType) {
		this.xmlType = xmlType;
	}
	
}
