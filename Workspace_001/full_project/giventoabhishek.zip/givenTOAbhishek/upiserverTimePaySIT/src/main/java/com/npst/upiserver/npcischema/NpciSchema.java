package com.npst.upiserver.npcischema;

public class NpciSchema {

}
