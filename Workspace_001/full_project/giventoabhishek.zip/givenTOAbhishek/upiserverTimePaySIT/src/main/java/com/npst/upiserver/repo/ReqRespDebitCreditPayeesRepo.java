package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.ReqRespDebitCreditPayeesEntity;

public interface ReqRespDebitCreditPayeesRepo extends JpaRepository<ReqRespDebitCreditPayeesEntity, Long> {

}
