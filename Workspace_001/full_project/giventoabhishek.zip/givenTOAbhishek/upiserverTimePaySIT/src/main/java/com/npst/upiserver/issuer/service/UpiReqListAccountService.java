package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqListAccount;

public interface UpiReqListAccountService {
	void issuerProcess(ReqListAccount reqListAccount);
}
