package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqMandate;

public interface UpiReqMandateService {
	void issuerProcess(ReqMandate reqMandate);
}
