package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.TransServerEntity;

public interface TransServerRepo extends JpaRepository<TransServerEntity, Long> {

}