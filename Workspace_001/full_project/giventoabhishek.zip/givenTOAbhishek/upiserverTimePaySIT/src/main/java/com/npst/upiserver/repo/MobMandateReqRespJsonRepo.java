package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.MobMandateReqRespJsonEntity;

public interface MobMandateReqRespJsonRepo extends JpaRepository<MobMandateReqRespJsonEntity, Long> {

	MobMandateReqRespJsonEntity findByIdPk(long idPk);
}
