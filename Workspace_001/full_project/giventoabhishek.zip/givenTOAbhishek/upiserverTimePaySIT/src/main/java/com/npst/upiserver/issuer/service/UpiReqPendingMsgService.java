package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqPendingMsg;

public interface UpiReqPendingMsgService {
	void issuerProcess(ReqPendingMsg reqPendingMsg);
}
