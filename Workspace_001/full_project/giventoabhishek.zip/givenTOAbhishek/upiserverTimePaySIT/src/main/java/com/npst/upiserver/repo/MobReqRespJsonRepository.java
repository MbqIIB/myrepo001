package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.MobReqRespJson;


public interface MobReqRespJsonRepository extends JpaRepository<MobReqRespJson,Long> {

	MobReqRespJson findByIdmobreqrespjson(Long idmobreqrespjson);
}
