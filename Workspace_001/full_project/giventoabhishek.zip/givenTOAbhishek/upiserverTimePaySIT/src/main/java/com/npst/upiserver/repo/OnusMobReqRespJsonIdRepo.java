/*package com.npst.upiserver.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.OnusMobReqRespJsonIdEntity;

public interface OnusMobReqRespJsonIdRepo extends JpaRepository<OnusMobReqRespJsonIdEntity, Long> {

	OnusMobReqRespJsonIdEntity findByIdonusmobreqrespjsonid(long idpk);

}
*/