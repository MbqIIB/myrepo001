package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqPay;

public interface UpiReqPayService {
	void issuerProcess(ReqPay reqPay);
}
