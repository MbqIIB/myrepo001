package com.npst.upiserver.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.npst.upiserver.entity.ReqRespAuthMandatePayeesEntity;

public interface ReqRespAuthMandatePayeesRepo extends JpaRepository<ReqRespAuthMandatePayeesEntity, Long> {

	
	List<ReqRespAuthMandatePayeesEntity> findByIdReqRespAuthMandate(long idReqRespAuthMandate);
}
