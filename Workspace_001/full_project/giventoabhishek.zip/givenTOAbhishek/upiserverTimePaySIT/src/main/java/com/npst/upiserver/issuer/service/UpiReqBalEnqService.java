package com.npst.upiserver.issuer.service;

import com.npst.upiserver.npcischema.ReqBalEnq;

public interface UpiReqBalEnqService {
	void issuerProcess(ReqBalEnq reqBalEnq);
}
